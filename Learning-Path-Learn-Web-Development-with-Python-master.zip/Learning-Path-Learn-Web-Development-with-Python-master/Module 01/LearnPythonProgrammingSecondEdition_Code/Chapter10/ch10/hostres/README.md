# Hostname Resolution

In order to run the tests just make sure you are in this folder
and then run:

```
$ pytest -vv -x tests
```
