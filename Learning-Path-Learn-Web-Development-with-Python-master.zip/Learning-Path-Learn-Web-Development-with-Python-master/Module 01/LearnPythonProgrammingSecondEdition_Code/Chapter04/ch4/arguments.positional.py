def func(a, b, c):
    print(a, b, c)

func(1, 2, 3)  # prints: 1 2 3
