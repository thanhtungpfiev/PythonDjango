from itertools import permutations
print(list(permutations('ABC')))
