surnames = ['Rivest', 'Shamir', 'Adleman']
for surname in surnames:
    print(surname)
